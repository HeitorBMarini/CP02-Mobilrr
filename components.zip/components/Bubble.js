import {  View, StyleSheet, Text } from 'react-native'

export default props => {
  const styles = [style.bubble]
  if(props.messageIn) styles.push(style.itemIn)
  if(props.messageOut) styles.push(style.itemOut)
  return (
    <View>
      <Text style={styles}>{props.message}</Text>
    </View>
  )
}

const style = StyleSheet.create({
  bubble: {
    padding: 10,
    borderRadius: 20,
    maxWidth: 250,
    marginTop: 10
  },
  itemIn: {
    backgroundColor: '#cccccc',
    alignSelf: 'flex-start', 
  },
  itemOut: {
    backgroundColor: '#00cc00',
    alignSelf: 'flex-end',
    color: '#fff',
  }
})