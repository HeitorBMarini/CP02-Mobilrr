import React, { useState, useEffect } from 'react';
import {View,SafeAreaView,ScrollView,FlatList} from 'react-native';
import Bubble from './Bubble';
import TextInputComponent from './TextInputComponent';

function Chat({ navigation }) {
  const [message, setMessage] = useState('');
  const [messageList, setMessageList] = useState([]);

  const sendMessage = () => {
    console.log(message);
    const updatedMessageList = [...messageList, message];
    setMessageList(updatedMessageList);
    updatedMessageList.forEach((message) => {
      console.log(message);
    });
    setMessage('');
  };

  return (
    <SafeAreaView style={styles.container}>
      <View>
        <ScrollView>
          <FlatList
            data={messageList}
            renderItem={({ item }) => <Bubble messageIn message={item} />}
            keyExtractor={(item, index) => index.toString()}
          />
        </ScrollView>
        <TextInputComponent
          value={message}
          onChangeText={setMessage}
          onClick={sendMessage}
        />
      </View>
    </SafeAreaView>
  );
}

const styles = {
  container: {
    flex: 1,
  },
};

export default Chat;