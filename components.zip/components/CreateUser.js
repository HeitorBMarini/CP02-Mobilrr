import React, { useState, useEffect } from 'react';
import { Text, StyleSheet, SafeAreaView, TextInput, Button } from 'react-native';
import * as firebase from 'firebase';

function CriarUsuario({ navigation }) {
  const auth = firebase.auth();
  const database = firebase.database();
  const [user, setUser] = useState(null);
  const [nome, setNome] = useState('');
  const [sobrenome, setSobrenome] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');

  useEffect(() => {
    const subscriber = auth.onAuthStateChanged((user) => {
      setUser(user);
    });
    return subscriber;
  }, [auth]);

  if (user) {
    navigation.navigate('Chat List');
  }

  const validatePassword = () => {
    if (password.length < 6) {
      alert('Senha precisa ter ao menos 6 caracteres');
    } 
  };

  const handleSignUp = () => {
    if (password === confirmPassword) {
      auth
        .createUserWithEmailAndPassword(email, password)
        .then((userCredential) => {
          setUser(userCredential.user);
          database.ref(`usuario/${userCredential.user.uid}`).set({
            email: email,
            nome: nome,
            sobrenome: sobrenome,
          });
        })
        .catch((error) => {
          console.log(error);
        });
    } else {
      alert('As senhas não coincidem');
    }
  };

  return (
    <SafeAreaView style={style.container}>
      <Text style={style.title}> Create </Text>
      <TextInput
        style={style.input}
        placeholder="Name"
        onChangeText={(nome) => setNome(nome)}
      />
      <TextInput
        style={style.input}
        placeholder="Lastname"
        onChangeText={(sobrenome) => setSobrenome(sobrenome)}
      />
      <TextInput
        style={style.input}
        placeholder="Email"
        onChangeText={(email) => setEmail(email)}
      />
      <TextInput
        style={style.input}
        secureTextEntry
        placeholder="Password"
        onChangeText={(password) => setPassword(password)}
        onBlur={validatePassword}
      />
      <TextInput
        style={style.input}
        secureTextEntry
        placeholder="Confirm password"
        onChangeText={(confirmPassword) => setConfirmPassword(confirmPassword)}
      />
      <Button title="Sign up" onPress={handleSignUp} />
    </SafeAreaView>
  );
}

const style = StyleSheet.create({
  container: {
    flex: 1,
    marginTop: 50,
    alignItems: 'center',
  },
  input: {
    borderWidth: 1,
    borderColor: 'black',
    borderRadius: 4,
    padding: 8,
    marginVertical: 8,
    minWidth: '80%',
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 16,
    marginTop: 25,
  },
});

export default CriarUsuario;
