import { View, TextInput, TouchableOpacity, StyleSheet, Image } from 'react-native'

export default props => {
  return (
    <View style={style.container}>
    <TextInput style={style.inputText} onChangeText={message => props.onTextChanged(message) } />
    <TouchableOpacity style={style.sendButton} onPress={ () => props.onClick() }>
    <Image source={require('../assets/snack-icon.png')} style={style.image} />
    </TouchableOpacity>
    </View>
  )
}

const style = StyleSheet.create({
  container: {
    padding: 5,
    flexDirection: 'row',
    flexWrap: 'wrap'
  },
  inputText: {
    backgroundColor: '#f2f2f2',
    maxHeight: 150,
    borderRadius: 25,
    flex: 1,
    paddingHorizontal: 10
  },
  sendButton: {
    width: 50,
    height: 50,
    borderRadius: 25,
    marginStart: 10,
    backgroundColor: '#006600',
    justifyContent: 'center',
    alignItems: 'center'
  },
  image: {
    width: 30,
    height: 30
  }
})