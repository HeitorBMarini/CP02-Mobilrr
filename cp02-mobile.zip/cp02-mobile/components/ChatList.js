import React, { useState, useEffect } from 'react';
import {View,Text,StyleSheet,SafeAreaView,TouchableOpacity,} from 'react-native';
import * as firebase from 'firebase';


function ChatList({ navigation }) {
  const auth = firebase.auth();
  const database = firebase.database();
  const [listaUsuario, setListaUsuario] = useState([]);

  useEffect(() => {
    const getUsuarios = async () => {
      try {
        const lista = [];
        await database
          .ref('usuario/')
          .once('value')
          .then((snapshot) => {
            snapshot.forEach((item) => {
              const key = item.key;
              const dados = item.val();

              if (dados.email !== auth.currentUser.email) {
                const itemUsuario = {
                  id: key,
                  nome: dados.nome || '',
                  sobrenome: dados.sobrenome || '',
                  email: dados.email || '',
                };
                lista.push(itemUsuario);
              }
            });
          });
        setListaUsuario(lista);
      } catch (e) {
        console.warn(e);
      }
    };

    getUsuarios();
  }, [database, auth]);

  return (
    <SafeAreaView style={style.container}>
      <View>
        {listaUsuario.map((usuario) => (
          <TouchableOpacity key={usuario.id}>
            <Text style={style.container2}>
              {usuario.nome} {usuario.sobrenome}
            </Text>
            <Text>{usuario.email}</Text>
          </TouchableOpacity>
        ))}
      </View>

      <TouchableOpacity
      style={style.container}
        onPress={() => {
          auth.signOut().then(() => {
            navigation.goBack('Login');
          });
        }}>
        <Text style={style.title2}>Deslogar</Text>
      </TouchableOpacity>
    </SafeAreaView>
  );
}


const style = StyleSheet.create({
  container: {
    flex: 1,
    marginTop: 50,
    alignItems: 'center',
  },
  container2: {
    flex: 1,
    marginTop: 50,
    alignItems: 'center',
    fontSize: 18,
    fontWeight: 'bold',
  },
  title2: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 16,
    marginTop: 30,
  },
});

export default ChatList;