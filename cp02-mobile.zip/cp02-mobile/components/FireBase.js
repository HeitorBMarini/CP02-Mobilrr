import React, { useEffect, useState } from 'react';
import * as firebase from 'firebase';


const FirebaseContext = React.createContext();

const Firebase = ({ children }) => {
  const [firebaseApp, setFirebaseApp] = useState(null);

  useEffect(() => {
    if (!firebase.apps.length) {
      const app = firebase.initializeApp({
        apiKey: 'AIzaSyCOIEMawvjpyThmJTgXEjRLo5ovnipa9M8',
        authDomain: 'bigfiap.firebaseapp.com',
        databaseURL: 'https://bigfiap-default-rtdb.firebaseio.com/',
        projectId: 'bigfiap',
        storageBucket: 'bigfiap.appspot.com',
        messagingSenderId: '741916212372',
      });
      setFirebaseApp(app);
    } else {
      setFirebaseApp(firebase.apps[0]);
    }
  }, []);

  return (
    <FirebaseContext.Provider value={{ firebaseApp }}>
      {firebaseApp && children}
    </FirebaseContext.Provider>
  );
};

export { Firebase, FirebaseContext };
