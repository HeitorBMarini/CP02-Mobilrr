import React, { useState, useEffect,useCallback } from 'react';
import {SafeAreaView,Text,TextInput,View,Button,StyleSheet,Image,KeyboardAvoidingView,} from 'react-native';
import * as firebase from 'firebase';
import AsyncStorage from '@react-native-async-storage/async-storage';

function Login({ navigation }) {
  const auth = firebase.auth();
  const [initializing, setInitializing] = useState(true);
  const [user, setUser] = useState();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const saveUserEmailToStorage = useCallback(async () => {
    await AsyncStorage.setItem('userEmail', email);
  }, [email]);

  useEffect(() => {
    const subscriber = auth.onAuthStateChanged((user) => {
      setUser(user);
      if (initializing) {
        setInitializing(false);
      }
    });

    const getEmailFromStorage = async () => {
      const storedEmail = await AsyncStorage.getItem('userEmail');
      if (storedEmail !== null) {
        setEmail(storedEmail);
      }
    };
    getEmailFromStorage();

    return () => subscriber();
  }, []);

  useEffect(() => {
    if (user) {
      navigation.navigate('Chat List');
    }
  }, [user, navigation]);

  const handleLogin = useCallback(async () => {
    if (!email || !password) {
      alert('Preencha o email e a senha');
      return;
    }

    try {
      await auth.signInWithEmailAndPassword(email, password);
      setUser(auth.currentUser);
      saveUserEmailToStorage();
      setPassword('');
      setEmail('');
      alert('Login com sucesso');
    } catch (error) {
      alert('Falha ao logar');
    }
  }, [auth, email, password, saveUserEmailToStorage]);

  return (
    <SafeAreaView style={style.container}>
      <KeyboardAvoidingView behavior="padding" style={style.container}>
        <Image style={style.image2} source={require('../assets/perfil.png')} />
        <Text style={style.title}>Login</Text>
        <TextInput
          style={style.input}
          placeholder="Email"
          onChangeText={setEmail}
          onBlur={saveUserEmailToStorage}
          value={email}
        />
        <TextInput
          style={style.input}
          secureTextEntry
          placeholder="Password"
          onChangeText={setPassword}
          value={password}
        />
        <View style={style.button}>
          <Button title="Login" onPress={handleLogin} />
        </View>
        <View style={style.button2}>
          <Button
            title="Sing up"
            onPress={() => navigation.navigate('Criar Usuário')}
          />
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const style = StyleSheet.create({
  container: {
    flex: 1,
    marginTop: 50,
    alignItems: 'center',
  },
  input: {
    borderWidth: 1,
    borderColor: 'black',
    borderRadius: 4,
    padding: 8,
    marginVertical: 8,
    minWidth: '80%',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 16,
    marginTop: 25,
  },
  button: {
    padding: 8,
    marginVertical: 5,
    minWidth: '83%',
  },
  button2: {
    marginTop: 45,
    marginLeft: 185,
  },
  image2: {
    width: 50,
    height: 50,
    borderRadius: 50,
    marginTop: 50,
  },
});

export default Login;
